SELECT  servicename as Service_Display_Name,
	   service_account as Service_Account,
        instant_file_initialization_enabled as Instant_File_Initialization_Enabled
FROM    sys.dm_server_services
WHERE   servicename LIKE 'SQL Server (%'